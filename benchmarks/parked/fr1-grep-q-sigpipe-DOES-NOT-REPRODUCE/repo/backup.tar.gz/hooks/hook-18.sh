hook 18
