hook 32
