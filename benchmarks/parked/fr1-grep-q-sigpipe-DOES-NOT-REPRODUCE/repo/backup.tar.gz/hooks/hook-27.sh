hook 27
